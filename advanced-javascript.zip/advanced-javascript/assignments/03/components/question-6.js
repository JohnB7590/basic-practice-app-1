function answer6() {
  function convertMeToArrowSyntax(a, b, c) {
    return a * (b - c);
  }

  return convertMeToArrowSyntax(3, 7, 5);
}
