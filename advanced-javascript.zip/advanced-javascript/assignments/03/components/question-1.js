const renderQuestion1 = () => {
  ReactDOM.render(
    <h1>Hello, world!</h1>,
    document.getElementById('root')
  );
};

links.push({
  label: "Question 1 Answer",
  clickHandler: renderQuestion1
});
