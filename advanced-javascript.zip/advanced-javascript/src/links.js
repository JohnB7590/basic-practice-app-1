const links = [];

const addLink = (label, clickHandler) => links.push({
  label: label,
  clickHandler: clickHandler
});

